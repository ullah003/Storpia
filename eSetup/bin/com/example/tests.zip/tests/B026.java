//The contents of the power option setting operates normally?
//전원옵션 설정의 내용이 정상적으로 동작 되는가?


package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class B026 {
	private static WebDriver driver;
	private static String baseUrl;
	private static StringBuffer verificationErrors = new StringBuffer();

	public static void main(String[] args) throws InterruptedException {
		String day = "";
		String hour = "";
		String minute = "";
		WebElement wakeOnLAN;
		WebElement scheduledPowerOn;
		WebElement scheduledShutdown;
		WebElement hibernation;
		boolean status_scheduledPowerOn = false;
		boolean status_scheduledShutdown = false;
		boolean status_wakeOnLAN = false;
		boolean status_hibernation = false;
		
		// Before
		driver = new FirefoxDriver();
		baseUrl = "http://192.168.1.9:9000/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		// Test
		driver.get(baseUrl + "/");
		driver.findElement(By.id("login_userid")).clear();
		driver.findElement(By.id("login_userid")).sendKeys("admin");
		driver.findElement(By.id("login_password")).clear();
		driver.findElement(By.id("login_password")).sendKeys("admin");
		driver.findElement(By.cssSelector("input.btn_login")).click();
		for (int second = 0;; second++) {
			if (second >= 60) fail("timeout");
			try { if (isElementPresent(By.name("icon_esetup"))) break; } catch (Exception e) {}
			Thread.sleep(1000);
		}
		
		System.out.println("------------------ Test Case ----------------------");
		System.out.println("전원옵션 설정의 내용이 정상적으로 동작 되는가?");
		System.out.println("Power setting options can be set normally?");
		System.out.println("---------------------------------------------------");
		
		driver.findElement(By.name("icon_esetup")).click();		

		// Click Power menu
		driver.findElement(By.xpath("//body/div/div[2]/div/div/div/div/ul/div/li[2]/ul/li[6]/div/a/span")).click();
		System.out.println("Move Power menu");
		Thread.sleep(3000);

		// Click Wake on LAN	
		if (isElementVisible(By.name("wol_enable"))){
			wakeOnLAN = driver.findElement(By.name("wol_enable"));
			if(!wakeOnLAN.isSelected()) {
				wakeOnLAN.click();
				System.out.println("Click Wake on LAN");
			}
			Thread.sleep(2000);
		}else
			System.out.println("WOL option is not present");
			
		// Click Scheduled Power On
		if (isElementVisible(By.name("turnon_enable"))){
			scheduledPowerOn = driver.findElement(By.name("turnon_enable"));
			if(!scheduledPowerOn.isSelected()) {
				System.out.println("Schedule power on is not activated currently. We will activate it.");
				scheduledPowerOn.click();
				System.out.println("Click Scheduled Power On");
			}	
				// Select Power on -> Day (everyday)
				driver.findElement(By.id("turnon_wday")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//body/div[14]/div/div[7]")).click();
				Thread.sleep(2000);
				// Select Power on -> time hour (01)
				driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/form/fieldset[2]/div/div/div[3]/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/img")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//body/div[15]/div/div[3]")).click();
				Thread.sleep(2000);
				
				// Select Power on -> time minute (04)
				driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/form/fieldset[2]/div/div/div[3]/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div/div/div/img")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//body/div[16]/div/div[6]")).click();
				Thread.sleep(2000);
//			}else{
//				System.out.println("Schedule power on is activated currently. We will disable it.");
//				scheduledPowerOn.click();
//			}
		}else
			System.out.println("Schedule power on is not present");

		// Click Scheduled Shutdown
		if (isElementVisible(By.name("shutdown_enable"))){
			scheduledShutdown = driver.findElement(By.name("shutdown_enable"));
			if(!scheduledShutdown.isSelected()) {
				scheduledShutdown.click();
				System.out.println("Click Scheduled Shutdown");
			}
			
			// Select Power on -> Day (everyday)
			driver.findElement(By.id("shutdown_wday")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//body/div[17]/div/div[7]")).click();
			Thread.sleep(2000);
			// Click Shutdown -> time hour (01)
			driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/form/fieldset[3]/div/div/div[3]/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/img")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//body/div[18]/div/div[6]")).click();
			Thread.sleep(2000);
	
			// Click Shutdown -> time minute (03)
			driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div[2]/form/fieldset[3]/div/div/div[3]/div/div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div/div/div/img")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//body/div[19]/div/div[10]")).click();
			Thread.sleep(2000);
		}else
			System.out.println("Schedule Shutdown is not present");

		// Disk Hibernation
				if (isElementVisible(By.id("sata_savemode"))){
					//hibernation = driver.findElement(By.id("sata_savemode"));
										
					// Select Hibernation -> Standby mode
					driver.findElement(By.id("sata_savemode")).click();
					Thread.sleep(1000);
					driver.findElement(By.xpath("//body/div[20]/div/div[2]")).click();
					Thread.sleep(3000);
					// Click waiting time -> 20 min
					driver.findElement(By.id("sata_wait_time")).click();
					Thread.sleep(1000);
					driver.findElement(By.xpath("//body/div[21]/div/div[2]")).click();
					Thread.sleep(2000);
				}else
					System.out.println("Disk Hibernation is not present");
		
		
		
		// Click Confirm Button
		driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div[2]/div/div/div/div/div/div/div/div/table/tbody/tr[2]/td[2]/em/button")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//button[contains(text(), 'OK')]")).click();

		//Refresh
		//System.out.println("Refresh Page");
		try{
			Thread.sleep(2000);
		} catch(Exception e) {}
		String url = driver.getCurrentUrl();  
		driver.navigate().to(url);  
		try{
			Thread.sleep(2000);
		} catch(Exception e) {}

		// Click Power menu
		driver.findElement(By.xpath("//body/div/div[2]/div/div/div/div/ul/div/li[2]/ul/li[6]/div/a/span")).click();

		Thread.sleep(1000);
		// get status
		if (isElementVisible(By.name("wol_enable"))){
			Thread.sleep(1000);
			wakeOnLAN = driver.findElement(By.name("wol_enable"));
				
			Thread.sleep(1000);
		
			// Check Wake on LAN
			if(wakeOnLAN.isSelected()) {
				status_wakeOnLAN = true;
				System.out.println("Wake on LAN is selected");			
			} else {
				System.out.println("Wake on LAN isn't chosen");
			}
		}	
		
		Thread.sleep(1000);
		// Check Scheduled Power On
		if (isElementVisible(By.name("turnon_enable"))){
			scheduledPowerOn = driver.findElement(By.name("turnon_enable"));
				
			if(scheduledPowerOn.isSelected()) {
				status_scheduledPowerOn = true;
				System.out.println("Scheduled Power On is selected");
				day = driver.findElement(By.id("turnon_wday")).getAttribute("value");
				hour = driver.findElement(By.id("turnon_hour")).getAttribute("value");
				minute = driver.findElement(By.id("turnon_min")).getAttribute("value");			
				System.out.println("System will be turned on at '" + day + "  " + hour + ":" + minute + "'");
				
			} else {
				System.out.println("Scheduled power on isn't chosen");
			}
		}
		
		Thread.sleep(1000);
		// Check Scheduled Shutdown
		if (isElementVisible(By.name("shutdown_enable"))){
			scheduledShutdown = driver.findElement(By.name("shutdown_enable"));
			
			if(scheduledShutdown.isSelected()) {
				status_scheduledShutdown = true;
				System.out.println("Scheduled Shutdown is selected");
				day = driver.findElement(By.id("shutdown_wday")).getAttribute("value");
				//hour = driver.findElement(By.id("shutdown_hour")).getText();
				hour = driver.findElement(By.id("shutdown_hour")).getAttribute("value");
				//minute = driver.findElement(By.id("shutdown_min")).getText();
				minute = driver.findElement(By.id("shutdown_min")).getAttribute("value");
				System.out.println("System will be shutdown at '" + day + "  "  + hour + ":" + minute + "'");
			} else {
				System.out.println("Scheduled Shutdown isn't chosen");
			}
			Thread.sleep(1000);
		}
		
		Thread.sleep(1000);
		// Check Hibernation
		if (isElementVisible(By.id("sata_savemode"))){
			hibernation = driver.findElement(By.id("sata_savemode"));
			
			
				status_hibernation = true;
				//System.out.println("Scheduled Shutdown is selected");
				day = driver.findElement(By.id("sata_savemode")).getAttribute("value");
				//hour = driver.findElement(By.id("shutdown_hour")).getText();
				//hour = driver.findElement(By.id("shutdown_hour")).getAttribute("value");
				//minute = driver.findElement(By.id("shutdown_min")).getText();
				minute = driver.findElement(By.id("sata_wait_time")).getAttribute("value");
				System.out.println("HDD Hibernation(Power Save) = " + day + " : " + minute);
			
			Thread.sleep(1000);
		}
		
		
//		if(status_wakeOnLAN && status_scheduledPowerOn && status_scheduledShutdown) {
//			System.out.println("Power Option settings are stored successfully.");
//		} else {
//			System.out.println("Power Option settings are failed.");
//		}

		// After
		//driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}

	}	

	private static boolean isElementPresent(By by) {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
	
	public static boolean isElementVisible(By by){
		return driver.findElement(by).isDisplayed();
	}
	
//	public static boolean isElementPresent(By by) {
//	    boolean flag = true;
//	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//	    if (!(driver.findElements(by).size() > 0)) {
//	        flag = false;
//	    } 
//	    driver.manage().timeouts().implicitlyWait(6, TimeUnit.SECONDS);
//	    return flag;
//	}

}
