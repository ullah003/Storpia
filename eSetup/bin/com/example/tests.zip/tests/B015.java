//쓰기캐쉬지원 동작이 정상적인가?
//Can enable disable write cache successfully?

package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class B015 {
	private static WebDriver driver;
	private static String baseUrl;
	private static String successMsg = "";
	private static StringBuffer verificationErrors = new StringBuffer();
	
	public static void main(String []args) throws Exception {
		// Before
		driver = new FirefoxDriver();
		baseUrl = "http://192.168.1.202:9000/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		// Test
		driver.get(baseUrl + "/index.php");
		driver.findElement(By.id("login_userid")).clear();
		driver.findElement(By.id("login_userid")).sendKeys("admin");
		driver.findElement(By.id("login_password")).clear();
		driver.findElement(By.id("login_password")).sendKeys("admin");
		driver.findElement(By.cssSelector("input.btn_login")).click();
		for (int second = 0;; second++) {
			if (second >= 60) fail("timeout");
			try { if (isElementPresent(By.name("icon_esetup"))) break; } catch (Exception e) {}
			Thread.sleep(1000);
		}

		driver.findElement(By.name("icon_esetup")).click();		
		//driver.findElement(By.xpath("//ul[@id='ext-gen119']/li[2]/div")).click();
		driver.findElement(By.linkText("Disk")).click();
		
		//driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div/div/ul/li[2]/a[2]/em/span/span")).click();
		driver.findElement(By.linkText("Disk Management")).click();
		//Select disk
		driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div/div/div/div/div/div/div/form/div/div/div/div/div[2]/div[2]/div/div/div[2]/div/div/table/tbody/tr/td/div")).click();
		//Click Write Cache support button
		driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div/div/div/div/div/div/div/form/div/div/div/div/div[2]/div/div/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[2]/td[2]/em/button")).click();
		
		//System.out.println("Write cache support popup open.");
		
		if (!driver.findElement(By.id("CacheEnable")).isSelected()){
			System.out.println("Currently Write Cache is NOT ENABLED, going to enable it. ");
			driver.findElement(By.id("CacheEnable")).click();
				
			driver.findElement(By.xpath("//button[contains(text(), 'Confirm')]")).click();
			Thread.sleep(1000);		
	
			successMsg = driver.findElement(By.xpath("/html/body/div[21]/div[2]/div/div/div/div/div/div[2]/span")).getText();
			System.out.println("Output : " + successMsg);
	
			driver.findElement(By.xpath("//button[contains(text(), 'OK')]")).click();
			
			//Select disk
			driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div/div/div/div/div/div/div/form/div/div/div/div/div[2]/div[2]/div/div/div[2]/div/div/table/tbody/tr/td/div")).click();
			//Click Write Cache support button
			driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div/div/div/div/div/div/div/form/div/div/div/div/div[2]/div/div/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[2]/td[2]/em/button")).click();
			
			if (driver.findElement(By.id("CacheEnable")).isSelected())
				System.out.println("Write Cache enabled successfully. ");
			else
				System.out.println("Write Cache enable failed. ");
					
			driver.findElement(By.xpath("//button[contains(text(), 'Close')]")).click();
		}else{
			System.out.println("Currently Write Cache is ENABLED, going to disable it. ");
			driver.findElement(By.id("CacheEnable")).click();
			
			driver.findElement(By.xpath("//button[contains(text(), 'Confirm')]")).click();
			Thread.sleep(1000);		
	
			successMsg = driver.findElement(By.xpath("/html/body/div[21]/div[2]/div/div/div/div/div/div[2]/span")).getText();
			System.out.println("Output : " + successMsg);
	
			driver.findElement(By.xpath("//button[contains(text(), 'OK')]")).click();
			
			//Select disk
			driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div/div/div/div/div/div/div/form/div/div/div/div/div[2]/div[2]/div/div/div[2]/div/div/table/tbody/tr/td/div")).click();
			//Click Write Cache support button
			driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div/div/div/div/div/div/div/form/div/div/div/div/div[2]/div/div/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[2]/td[2]/em/button")).click();
			
			if (!driver.findElement(By.id("CacheEnable")).isSelected())
				System.out.println("Write Cache DISABLED successfully. ");
			else
				System.out.println("Write Cache DISABLE failed. ");
					
			driver.findElement(By.xpath("//button[contains(text(), 'Close')]")).click();
		}
		
		// After
		//driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}	

	private static boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
}
