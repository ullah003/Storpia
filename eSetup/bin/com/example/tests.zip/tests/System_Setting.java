package com.example.tests;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class System_Setting {
	
	protected static WebDriver driver;
	private static String baseUrl, userID, userPass;
	
	public void Login() throws IOException {
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		BufferedReader br = new BufferedReader(new FileReader("D:\\SystemConf.txt"));
	    try {
	        for (int i=0; i<=2; i++){
	        	String line = br.readLine();
	        	String[] tokens = line.split("=");
            	if (tokens[0].equals("url")){
	        		baseUrl = tokens[1];
	        	}else if (tokens[0].equals("ID")){
	        		userID = tokens[1];
	        	}else if (tokens[0].equals("passwd")){
	        		userPass = tokens[1];
	        	}
	        }
	    } finally {
	        br.close();
	    }
		
		driver.get(baseUrl);
		driver.findElement(By.id("login_userid")).clear();
		driver.findElement(By.id("login_userid")).sendKeys(userID);
		driver.findElement(By.id("login_password")).clear();
		driver.findElement(By.id("login_password")).sendKeys(userPass);
		driver.findElement(By.cssSelector("input.btn_login")).click();
		driver.findElement(By.name("icon_esetup")).click();
	}

	
	public static void main(String[] args) throws IOException, InterruptedException {
		System_Setting objLogin = new System_Setting();
		objLogin.Login();
		
		B001 Network = new B001();
		Network.B001();
		
//		B002 DNS_Change = new B002();
//		DNS_Change.B002();
//		
//		B003 Static_DHCP = new B003();
//		Static_DHCP.B003();
//		
//		B007 DDNS = new B007();
//		DDNS.B007();
		
		pageRefresh();
		B008 Volume_Info = new B008();
		Volume_Info.B008();
		
		B014 Disk_Info = new B014();
		Disk_Info.B014();
		
		//driver.quit();
	}
	
	private static void pageRefresh() {
		//Refresh
		try{
			Thread.sleep(2000);
		} catch(Exception e) {}
		String url = driver.getCurrentUrl();  
		driver.navigate().to(url);  
		try{
			Thread.sleep(2000);
		} catch(Exception e) {}
	}

}
