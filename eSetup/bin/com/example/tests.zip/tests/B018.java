//After selecting USB disk can it be formated normally?
//usb 디스크 선택후 포맷 설정은 정상적인가?

package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class B018 {
	private static WebDriver driver;
	private static String baseUrl;
	private static String DiskName = "";
	private static String FileSystem = "";
	private static String FileSystemModified = "";
	private static String successMsg = "";
	private static StringBuffer verificationErrors = new StringBuffer();
	
	public static void main(String [] args) throws InterruptedException {
		// Before 
		driver = new FirefoxDriver();
		baseUrl = "http://192.168.1.9:9000/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		// Test
		driver.get(baseUrl + "/index.php");
		driver.findElement(By.id("login_userid")).clear();
		driver.findElement(By.id("login_userid")).sendKeys("admin");
		driver.findElement(By.id("login_password")).clear();
		driver.findElement(By.id("login_password")).sendKeys("admin");
		driver.findElement(By.cssSelector("input.btn_login")).click();
//		for (int second = 0;; second++) {
//			if (second >= 60) fail("timeout");
//			try { if (isElementPresent(By.name("icon_esetup"))) break; } catch (Exception e) {}
//			Thread.sleep(1000);
//		}

		driver.findElement(By.name("icon_esetup")).click();
		driver.findElement(By.xpath("//body/div/div[2]/div/div/div/div/ul/div/li[2]/ul/li[3]/div/a/span")).click();	// External Disk menu
		
		//When can't fetch disk information
		if (isElementPresent(By.xpath("//body/div[16]/div[2]/div/div/div/div/div/div[2]/span"))){
			successMsg = driver.findElement(By.xpath("//body/div[16]/div[2]/div/div/div/div/div/div[2]/span")).getText();
			System.out.println("Output : " + successMsg);
			if (!isElementPresent(By.xpath("//button[contains(text(), 'OK')]"))){
				driver.findElement(By.xpath("//button[contains(text(), 'OK')]")).click();
			}
		}
		
		for (int i =1; i<=6; i++){
			if (!isElementPresent(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/form/div/div[2]/div[2]/div/div/div[2]/div/div[" + i + "]/table/tbody/tr/td/div"))){
				if (i==1)
					System.out.println("-------------- No USB Connected ----------------");
				else
					System.out.println("-------------- No more USB Connected ----------------");
				break;
			}else{
				DiskName = driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/form/div/div[2]/div[2]/div/div/div[2]/div/div[" + i + "]/table/tbody/tr/td/div")).getText();
				FileSystem = driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/form/div/div[2]/div[2]/div/div/div[2]/div/div[" + i + "]/table/tbody/tr/td[7]/div")).getText();		
				System.out.println("DiskName \t File System" );	
				System.out.println(DiskName + "\t\t" + FileSystem);
				
				//select disk
				driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/form/div/div[2]/div[2]/div/div/div[2]/div/div[" + i + "]")).click();
				// Click format
				driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/form/div/div[2]/div/div/table/tbody/tr/td/table/tbody/tr/td[5]/table/tbody/tr[2]/td[2]/em/button")).click();
				Thread.sleep(1000);
				
				System.out.println("Going to format to EXT3");
				
				//Click File System
				//driver.findElement(By.xpath("//body/div[19]/div[2]/div/div/div/div/div/div/form/div[2]/div/div/input[2]")).click();
				
				//Select File System
				driver.findElement(By.xpath("//body/div[21]/div/div[3]")).click(); // EXT3
				
				driver.findElement(By.xpath("//button[contains(text(), 'Confirm')]")).click();
				
				System.out.println("=======================================" );
				successMsg = driver.findElement(By.xpath("//body/div[21]/div[2]/div/div/div/div/div/div[2]/span")).getText();
				System.out.println("Web Output : " + successMsg);
								
				if (successMsg.equals("External disk format failed")){
					driver.findElement(By.xpath("//button[contains(text(), 'OK')]")).click();
					driver.findElement(By.xpath("//button[contains(text(), 'Cancel')]")).click();
				}else{
					driver.findElement(By.xpath("//button[contains(text(), 'OK')]")).click();
				}
				
				DiskName = driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/form/div/div[2]/div[2]/div/div/div[2]/div/div[" + i + "]/table/tbody/tr/td/div")).getText();
				FileSystemModified = driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/form/div/div[2]/div[2]/div/div/div[2]/div/div[" + i + "]/table/tbody/tr/td[7]/div")).getText();
				
				System.out.println("DiskName \t volume Assign " );	
				System.out.println(DiskName + "\t\t" + FileSystem);
				
				if (FileSystem.equals(FileSystemModified)){
					System.out.println("Disk format failed!");
				}
				
			}
				//successMsg = driver.findElement(By.xpath("//body/div[21]/div[2]/div/div/div/div/div/div[2]/span")).getText();
				//System.out.println("Output : " + successMsg);
				//driver.findElement(By.xpath("//button[contains(text(), 'OK')]")).click();		
				
				Thread.sleep(3000);
				//FileSystem = driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/form/div/div[2]/div[2]/div/div/div[2]/div/div[" + i + "]/table/tbody/tr/td[8]/div")).getText();
				//if (FileSystem.equals("Yes"))
				//	System.out.println("USB activated SUCCESSFULLY.");
				//else
				//	System.out.println("USB activation FAILED.");	
			
		}
		// Select(disk1)
		//driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/form/div/div[2]/div[2]/div/div/div[2]/div/div")).click();
		
		// Click Format
		//driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/form/div/div[2]/div/div/table/tbody/tr/td/table/tbody/tr/td[5]/table/tbody/tr[2]/td[2]/em/button")).click();		
//		driver.findElement(By.xpath("//body/div[18]/div[2]/div/div/div/div/div/div/form/div[2]/div/div/input[2]")).click();
		//driver.findElement(By.xpath("//button[contains(text(), 'Confirm')]")).click();
		

//		if(isElementPresent(By.xpath("//body/div[18]/div[2]/div[2]/div/div/div/div/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[2]/td[2]/em/button"))) {
//			System.out.println("È®ÀÎ¹öÆ°ÀÌ Á¸ÀçÇÕ´Ï´Ù.");			
//		}		
		
		//////////////////////////////////////////////////////////////////////
		// È®ÀÎ¹öÆ°, Ãë¼Ò¹öÆ° Å¬¸¯ÀÌ ¾ÈµÊ
		//////////////////////////////////////////////////////////////////////
		
//		driver.findElement(By.xpath("//body/div[19]/div[2]/div[2]/div/div/div/div/table/tbody/tr/td[2]/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[2]/td[2]/em/button")).click(); // È®ÀÎ ¹öÆ° Å¬¸¯
		//driver.findElement(By.id("ext-gen249")).click();
		//System.out.println("È®ÀÎ");

		
//		if (isElementPresent(By.xpath("//body/div[20]/div/div"))) {
//			driver.findElement(By.xpath("//body/div[20]/div/div")).click(); // XFS Å¬¸¯
//			driver.findElement(By.xpath("//body/div[18]/div[2]/div[2]/div/div/div/div/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[2]/td[2]/em/button")).click(); // È®ÀÎ ¹öÆ° Å¬¸¯
//		}
		
		//System.out.println("Á¤»óÀûÀ¸·Î Æ÷¸ËÇÏ¿´½À´Ï´Ù.");
		
//		driver.findElement(By.xpath("//body/div[18]/div[2]/div[2]/div/div/div/div/table/tbody/tr/td[2]/table/tbody/tr/td/table/tbody/tr/td[2]/table/tbody")).click(); // Ãë¼Ò ¹öÆ° Å¬¸¯
		// After
		//driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

//	private static boolean isElementPresent(By by) {
//		try {
//			driver.findElement(by);
//			return true;
//		} catch (NoSuchElementException e) {
//			return false;
//		}
//	}
	
	public static boolean isElementPresent(By by) {
	    boolean flag = true;
	    driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	    if (!(driver.findElements(by).size() > 0)) {
	        flag = false;
	    } 
	    driver.manage().timeouts().implicitlyWait(6, TimeUnit.SECONDS);
	    return flag;
	}
}
