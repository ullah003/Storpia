//Can change language normally?
//언어 변경이 정상적으로 적용 되는가? 

package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


import com.thoughtworks.selenium.Selenium;

public class B020 {
	private static WebDriver driver;
	private static String baseUrl;
	private static StringBuffer verificationErrors = new StringBuffer();
	
	public static void main(String[] args) throws InterruptedException {
		// Before
		driver = new FirefoxDriver();
		baseUrl = "http://192.168.1.202:9000";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		// Test
		driver.get(baseUrl + "/index.php");
		driver.findElement(By.id("login_userid")).clear();
		driver.findElement(By.id("login_userid")).sendKeys("admin");
		driver.findElement(By.id("login_password")).clear();
		driver.findElement(By.id("login_password")).sendKeys("admin");
		driver.findElement(By.cssSelector("input.btn_login")).click();
		for (int second = 0;; second++) {
			if (second >= 60) fail("timeout");
			try { if (isElementPresent(By.name("icon_esetup"))) break; } catch (Exception e) {}
			Thread.sleep(1000);
		}

		driver.findElement(By.name("icon_esetup")).click();
		
		driver.findElement(By.xpath("//body/div/div[2]/div/div/div/div/ul/div/li[2]/ul/li[4]/div/a/span")).click();
		System.out.println("Language and Time menu......");
		
	for (int i =1; i<=6; i++){
		System.out.println("Test :" + i);
		//Changing system language
		String currentLang = driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/div/div/div[2]/div/div[2]/label")).getText();

		if (currentLang.equals("Display Language:")){
			System.out.println("Current system language : English \nChanging to Korean...");
			
			driver.findElement(By.id("languageWebView")).click(); // Click display language
			Thread.sleep(1000);
			
			driver.findElement(By.xpath("//body/div[14]/div/div[2]")).click(); // choose Korean lang
			//driver.findElement(By.xpath("//div[@class,'x-combo-list-item x-combo-selected']")).click(); // Korean ¼±ÅÃ
			//driver.findElement(By.xpath("//*[@id,'ext-gen215']/div/div[2]")).click(); // Korean ¼±ÅÃ
		}else{
			System.out.println("Current system language : Korean \nChanging to English...");
			
			driver.findElement(By.id("languageWebView")).click(); // Click display language
			Thread.sleep(1000);
			
			driver.findElement(By.xpath("//body/div[14]/div/div")).click(); // choose English lang
		}
				
		Thread.sleep(2000);		
		driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/div/table/tbody/tr[2]/td[2]")).click(); //confirm
		Thread.sleep(3000);
		String currentLang1 = driver.findElement(By.xpath("//body/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/div/div/div/div[2]/div/div[2]/label")).getText();
		
		if(currentLang1.equals(currentLang)) {
			System.out.println("Display language change failed.");
		}else{
			if(currentLang1.equals("Display Language:")) {
				System.out.println("Updated Language : English");
				System.out.println("Display language changed successfully.");
			} else if(currentLang1.equals("표시 언어:")) {
				System.out.println("Updated Language : Korean");
				System.out.println("Display language changed successfully.");
			}
		}
		System.out.println("=============================================");
	}
	
		// After
//		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}
	
//	@When("I select $elementId value $value")
	public static void selectComboValue(final String elementId, final String value) {
	    final Select selectBox = new Select(driver.findElement(By.xpath(elementId)));
	    selectBox.selectByValue(value);
	}
	

	private static boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
}
