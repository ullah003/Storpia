//E-mail setting can be done properly?
//메일설정이 정상적으로 저장 되는가?

package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class B022 {
	private static WebDriver driver;
	private static String baseUrl;
	private static StringBuffer verificationErrors = new StringBuffer();
	private static String strParam = "";
	
	public static void main(String [] args) throws InterruptedException {
		// Before
		driver = new FirefoxDriver();
		baseUrl = "http://192.168.1.202:9000/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		// Test
		driver.get(baseUrl + "/index.php");
		driver.findElement(By.id("login_userid")).clear();
		driver.findElement(By.id("login_userid")).sendKeys("admin");
		driver.findElement(By.id("login_password")).clear();
		driver.findElement(By.id("login_password")).sendKeys("admin");
		driver.findElement(By.cssSelector("input.btn_login")).click();
		for (int second = 0;; second++) {
			if (second >= 60) fail("timeout");
			try { if (isElementPresent(By.name("icon_esetup"))) break; } catch (Exception e) {}
			Thread.sleep(1000);
		}

		driver.findElement(By.name("icon_esetup")).click();
		driver.findElement(By.xpath("//body/div/div[2]/div/div/div/div/ul/div/li[2]/ul/li[5]/div/a/span")).click();		
		
		Thread.sleep(3000);		
		driver.findElement(By.name("smtpserver")).clear();		
		driver.findElement(By.name("smtpserver")).sendKeys("mail.gluesys.com");
		
		Thread.sleep(1000);
		driver.findElement(By.name("port")).clear();
		driver.findElement(By.name("port")).sendKeys("25");

		Thread.sleep(1000);
		if(!driver.findElement(By.name("tls_enable")).isSelected()) {
			driver.findElement(By.name("tls_enable")).click();
		}
		
		
		Thread.sleep(1000);
		if(!driver.findElement(By.name("auth_enable")).isSelected()){
			driver.findElement(By.name("auth_enable")).click();
		}
		
		
		Thread.sleep(1000);
		driver.findElement(By.name("auth_user")).clear();
		driver.findElement(By.name("auth_user")).sendKeys("storpia.support@gluesys.com");
		
		Thread.sleep(1000);
		driver.findElement(By.name("auth_passwd")).clear();
		driver.findElement(By.name("auth_passwd")).sendKeys("rajuraju");
		
		Thread.sleep(1000);
		driver.findElement(By.name("auth_passwd1")).clear();
		driver.findElement(By.name("auth_passwd1")).sendKeys("rajuraju");
		
		Thread.sleep(1000);
		driver.findElement(By.name("to1")).clear();
		driver.findElement(By.name("to1")).sendKeys("storpia.support@gluesys.com");
		
		Thread.sleep(1000);
		driver.findElement(By.name("to2")).clear();
		driver.findElement(By.name("to2")).sendKeys("support@storpia.com");		
		
		Thread.sleep(10000);
		
		driver.findElement(By.xpath("//button[contains(text(), 'Sending test e-Mail')]")).click();		
		Thread.sleep(3000);
		System.out.println("Send E-Mail successfully.");
		
		driver.findElement(By.xpath("//button[contains(text(), 'Confirm')]")).click();
		System.out.println("Setting successfully.");
		
		String temp = driver.findElement(By.name("smtpserver")).getText();	
		System.out.println("temp : " + temp);
		
		// After
		//driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
		
	}

	private static boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
}
